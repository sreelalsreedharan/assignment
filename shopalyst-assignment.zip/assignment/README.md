# Rest APIs created with Express and Data fetched from MySQL

## Project setup
```
npm install
```

### Run
```
node server.js
```
