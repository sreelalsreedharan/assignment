module.exports = app => {
  const products = require("../controllers/product.controller.js");

  // Retrieve all Products
  app.get("/products", products.getAllProducts);

  // Retrieve products by action
  app.get("/products/:action", products.findAllProductsByAction);
  
};
 