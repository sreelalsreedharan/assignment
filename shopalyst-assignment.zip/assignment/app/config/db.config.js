module.exports = {
  HOST: "localhost",
  USER: "root",  
  PASSOWRD: "",
  PORT:"3306",
  DB: "shopalyst"
};
