const Product = require("../models/product.model.js");


// Retrieve all Products.
exports.getAllProducts = (req, res) => {
  Product.getAllProducts((err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Products."
      });
    else res.send(data);
  });
};

// Filter Products by action
exports.findAllProductsByAction = (req, res) => {
  Product.findAllProductsByAction(req.params.action,req.query.brand,
    req.query.fromDate,req.query.toDate,
    (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Product with action ${req.params.action}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Product with action " + req.params.action
        });
      }
    } else res.send(data);
  });
};

