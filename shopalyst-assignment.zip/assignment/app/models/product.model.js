const sql = require("./db.js");

const Product = function(product) {

};

Product.findAllProductsByAction = (action,brand,fromDate,toDate, result) => {
  console.log(action);
  console.log(brand);
  console.log(fromDate);
  console.log(toDate);
   let filterQry = "";
  if(brand != null && brand != '' && brand != undefined){
  filterQry += '&& publisher_id =' + brand;
  }
  if(fromDate != null && fromDate != '' && fromDate != undefined
  && toDate != null && toDate != '' && toDate != undefined){
    filterQry += '&& time_stamp between' + fromDate + 'and' + toDate;
    } 

  sql.query(`SELECT distinct shopper_id,
  action, time_stamp, campaign_id, publisher_id,
  product_id,merchant,shopper_id,hashed_ip,user_agent,
  aff_source,aff_medium,aff_term,aff_campaign,aff_content,
  parent_org  
  FROM product_data WHERE action = ${action}
  ` + filterQry
  , (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("matching products: ", res);
      result(null, res);
      return;
    }

    // not found Customer with the id
    result({ kind: "not_found" }, null);
  });
};

Product.getAllProducts = result => {
  sql.query("SELECT * FROM product_data", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }
    console.log("Products: ", res);
    result(null, res);
  });
};



module.exports = Product;
